﻿using Volo.Abp.Localization;

namespace VP.BackgroundJobManager.Localization;

[LocalizationResourceName("BackgroundJobManager")]
public class BackgroundJobManagerResource
{

}
