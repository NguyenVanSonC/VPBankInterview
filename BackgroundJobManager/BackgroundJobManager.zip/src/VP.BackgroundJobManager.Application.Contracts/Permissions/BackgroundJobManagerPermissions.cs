﻿namespace VP.BackgroundJobManager.Permissions;

public static class BackgroundJobManagerPermissions
{
    public const string GroupName = "BackgroundJobManager";

    //Add your own permission names. Example:
    //public const string MyPermission1 = GroupName + ".MyPermission1";
}
