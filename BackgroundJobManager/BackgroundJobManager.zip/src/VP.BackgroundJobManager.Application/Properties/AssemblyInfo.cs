﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("VP.BackgroundJobManager.Application.Tests")]
