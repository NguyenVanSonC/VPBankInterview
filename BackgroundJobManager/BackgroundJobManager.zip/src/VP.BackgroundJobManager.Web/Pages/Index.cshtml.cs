﻿namespace VP.BackgroundJobManager.Web.Pages;

public class IndexModel : BackgroundJobManagerPageModel
{
    public void OnGet()
    {

    }
}
