﻿using AutoMapper;

namespace VP.BackgroundJobManager.Web;

public class BackgroundJobManagerWebAutoMapperProfile : Profile
{
    public BackgroundJobManagerWebAutoMapperProfile()
    {
        //Define your AutoMapper configuration here for the Web project.
    }
}
