﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("VP.BackgroundJobManager.Web.Tests")]
