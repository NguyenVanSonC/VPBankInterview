﻿namespace VP.BackgroundJobManager.Web.Menus;

public class BackgroundJobManagerMenus
{
    private const string Prefix = "BackgroundJobManager";
    public const string Home = Prefix + ".Home";

    //Add your menu items here...

}
