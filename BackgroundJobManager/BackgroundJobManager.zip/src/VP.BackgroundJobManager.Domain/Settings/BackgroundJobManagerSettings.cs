﻿namespace VP.BackgroundJobManager.Settings;

public static class BackgroundJobManagerSettings
{
    private const string Prefix = "BackgroundJobManager";

    //Add your own setting names here. Example:
    //public const string MySetting1 = Prefix + ".MySetting1";
}
