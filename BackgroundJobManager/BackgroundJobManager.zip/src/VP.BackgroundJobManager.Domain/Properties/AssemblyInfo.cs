﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("VP.BackgroundJobManager.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("VP.BackgroundJobManager.TestBase")]
