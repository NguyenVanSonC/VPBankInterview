﻿namespace VP.BackgroundJobManager;

public static class BackgroundJobManagerConsts
{
    public const string DbTablePrefix = "App";

    public const string DbSchema = null;
}
