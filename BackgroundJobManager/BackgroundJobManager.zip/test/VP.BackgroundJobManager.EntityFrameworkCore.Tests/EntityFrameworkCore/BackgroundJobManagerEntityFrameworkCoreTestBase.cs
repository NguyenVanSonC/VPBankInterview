﻿using Volo.Abp;

namespace VP.BackgroundJobManager.EntityFrameworkCore;

public abstract class BackgroundJobManagerEntityFrameworkCoreTestBase : BackgroundJobManagerTestBase<BackgroundJobManagerEntityFrameworkCoreTestModule>
{

}
