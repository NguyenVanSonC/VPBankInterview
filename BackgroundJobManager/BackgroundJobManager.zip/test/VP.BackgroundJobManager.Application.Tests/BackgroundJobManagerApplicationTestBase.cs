﻿namespace VP.BackgroundJobManager;

public abstract class BackgroundJobManagerApplicationTestBase : BackgroundJobManagerTestBase<BackgroundJobManagerApplicationTestModule>
{

}
