﻿namespace VP.BackgroundJobManager;

public abstract class BackgroundJobManagerDomainTestBase : BackgroundJobManagerTestBase<BackgroundJobManagerDomainTestModule>
{

}
